#include "mp_server.h"
#include "mp_core.h"
#include "TencentWiFi.h"
#include <stdio.h>
#include <time.h>
#include <signal.h>
#include <pthread.h>
#include "router_server.h"
#include "router_log.h"



/* Function prototypes */

/* functions to handle connections */
void handle_tcp_client(int clntSocket); /* TCP client handling function */
int handle_set_WMM_traffic(cJSON *jobjReceived);
int handle_quit_cmd(cJSON *jobjReceived);
int handle_clear_WMM_traffic(cJSON *jobjReceived);
int handle_set_WMM_parameter(cJSON *jobjReceived);
int handle_handshake_cmd(int index,cJSON *jobjReceived);
int handle_heartbeat_cmd(int index,cJSON *jobjReceived);
int handle_finish_cmd(int index,cJSON *jobjReceived);

//int handle_BQW_config(char* session_id,char *value_string,char *probability_string);

void send_heartbeat_response(int index,int result,char *jdata_string);
void send_handshake_response(int index,int result,int mp_version_num,char *report);
void send_finish_response(int index,int result);

struct JSON_CMD json_cmds[MAX_WLAN_CMDS];
uint32_t mp_version_num = 1005;
int timer_ms = 200;

int main(int argc, char *argv[])
{
    int port;

    sprintf(json_cmds[0].cmd_string,"start.handshake.req");
    json_cmds[0].handle_function = handle_handshake_cmd;
    sprintf(json_cmds[1].cmd_string,"start.heartbeat.req");
    json_cmds[1].handle_function = handle_heartbeat_cmd;
    sprintf(json_cmds[2].cmd_string,"start.finish.req");
    json_cmds[2].handle_function = handle_finish_cmd;

    init_proxy_list();

    if (argc != 2) { /* Test for correct number of arguments */
        fprintf(stderr, "Usage:  %s <Server Port>\n", argv[0]);
        exit(1);
    }

    port = atoi(argv[1]);
    if (port <= 1024 || port > 65534) {
        fprintf(stderr, "Fail to start router server with invalid port[%d], you should input valid param port\n",
               port);
        return -1;
    }

    printf("===============Begin StartRouter Port:%d=============\n", port);
    startRouterListen(port);
    printf("===============End StartRouter=============\n");



  /* NOT REACHED */
}


int handle_json(int index,char *objReceived) 
{
  cJSON *jobjReceived;
  jobjReceived = cJSON_CreateObject();
  jobjReceived = cJSON_Parse(objReceived);
  char *cmd_string = cJSON_GetObjectItemCaseSensitive(jobjReceived, "cmd")->valuestring;

	if (cmd_string!=NULL) {
    for (int i =0;i<MAX_WLAN_CMDS;i++) {
      if(strcmp(cmd_string,json_cmds[i].cmd_string)==0) {
        json_cmds[i].handle_function(index,jobjReceived);
		break;
      }
    }
  }
  cJSON_Delete(jobjReceived);
}

int handle_finish_cmd(int index,cJSON *jobjReceived) {
  char *session_id = NULL;
  int result=0;

  DEBUG_LOG_I("handle_finish_cmd enter\n");

  if(cJSON_HasObjectItem(jobjReceived,"instanceid")) {
    session_id = cJSON_GetObjectItemCaseSensitive(jobjReceived,"instanceid")->valuestring;
  } else {
    DEBUG_LOG_E("Cannot find instanceid in JSON->data");
    send_finish_response(index,-1); 
    return -1;
  }

  result = mp_stop_session(session_id, SESSION_STOPREASON_NORMAL);
  if(result == 0){
	  DEBUG_LOG_I("finish execution success\n");
  }

  send_finish_response(index,result); 

}

void send_finish_response(int index,int result) {
  cJSON *jobjToSend = cJSON_CreateObject();
  char result_str[32];
  sprintf(result_str, "%d", result);

  cJSON_AddItemToObject(jobjToSend, "cmd", cJSON_CreateString("start.finish.rsp"));
  cJSON_AddItemToObject(jobjToSend, "result", cJSON_CreateString(result_str));

  char *request = cJSON_PrintUnformatted(jobjToSend);
  handleSendData(index, request, strlen(request)+1);

  free(request);
  cJSON_Delete(jobjToSend);
}


int handle_heartbeat_cmd(int index,cJSON *jobjReceived) {
  cJSON *jdata=NULL;
  char *session_id = NULL;
  int result=0;
  char* jdata_string = NULL;

  if(cJSON_HasObjectItem(jobjReceived,"instanceid")) {
    session_id = cJSON_GetObjectItemCaseSensitive(jobjReceived,"instanceid")->valuestring;
  } else {
    DEBUG_LOG_E("Cannot find instanceid in JSON");
    result = -1;
  }

  if(cJSON_HasObjectItem(jobjReceived,"data")) {
    jdata = cJSON_GetObjectItem(jobjReceived,"data");
  } else {
    DEBUG_LOG_E("Cannot find data in JSON");
    result = -1;
  }

  if (result!=-1) {
    result = mp_report_heartbeat(session_id);
    jdata_string = cJSON_Print(jdata);
	  send_heartbeat_response(index,result,jdata_string);
    free(jdata_string);
	  if(result == 0){
	    DEBUG_LOG_I("heartbeat execution success\n");
	  }
  } 
  
}


void send_heartbeat_response(int index,int result,char *jdata_string) {
  cJSON *jobjToSend = cJSON_CreateObject();
  char result_str[32];
  sprintf(result_str, "%d", result);


  cJSON_AddItemToObject(jobjToSend, "cmd", cJSON_CreateString("start.heartbeat.rsp"));
  cJSON_AddItemToObject(jobjToSend, "result", cJSON_CreateString(result_str));
  cJSON_AddItemToObject(jobjToSend, "data",  cJSON_Parse(jdata_string));
  

  char *request = cJSON_PrintUnformatted(jobjToSend);
  handleSendData(index, request, strlen(request)+1);

  free(request);
  cJSON_Delete(jobjToSend);

}



int handle_handshake_cmd(int index,cJSON *jobjReceived) 
{
  cJSON *jhead=NULL;
  cJSON *jdata=NULL;
  cJSON *jconfig=NULL;
  char *session_id = NULL;
  char *acc_ip = NULL;
  char *port = NULL;
  char *report_ip = NULL;
  char *report_port = NULL;
  char default_report_port[] = "20009";
  char *app_id = NULL;
  char *bqw_str = NULL;
  char *interval_str = NULL;
  int result = 0;
  char report[MAX_STRING_LENGTH];
  int hit_flag = 0;


  if(cJSON_HasObjectItem(jobjReceived,"head")) {
    jhead = cJSON_GetObjectItemCaseSensitive(jobjReceived,"head")->child;
  } else {
    DEBUG_LOG_E("Cannot find head in JSON");
    result = -1;
  }

  if(cJSON_HasObjectItem(jobjReceived,"data")) {
    jdata = cJSON_GetObjectItem(jobjReceived,"data");

    if(cJSON_HasObjectItem(jdata,"instanceid")) {
      session_id = cJSON_GetObjectItemCaseSensitive(jdata,"instanceid")->valuestring;
    } else {
      DEBUG_LOG_E("Cannot find instanceid in JSON->data");
      result = -1;
    }

    if(cJSON_HasObjectItem(jdata,"accip")) {
      acc_ip = cJSON_GetObjectItemCaseSensitive(jdata,"accip")->valuestring;
    } else {
      DEBUG_LOG_E("Cannot find acc_ip in JSON->data");
      result = -1;
    }

    if(cJSON_HasObjectItem(jdata,"port")) {
      port = cJSON_GetObjectItemCaseSensitive(jdata,"port")->valuestring;
    } else {
      DEBUG_LOG_E("Cannot find port in JSON->data");
      result = -1;
    } 

    if(cJSON_HasObjectItem(jdata,"reportdomain")) {
      report_ip = cJSON_GetObjectItemCaseSensitive(jdata,"reportdomain")->valuestring;
    } else {
      DEBUG_LOG_E("Cannot find report_ip in JSON->data");
      if (acc_ip!=NULL) {
        report_ip = acc_ip;
      } else {

        return -1;

      }
    }

    if(cJSON_HasObjectItem(jdata,"reportport")) {
      report_port = cJSON_GetObjectItemCaseSensitive(jdata,"reportport")->valuestring;
    } else {
      DEBUG_LOG_E("Cannot find report_port in JSON->data");
      report_port = default_report_port;
    } 

    if(cJSON_HasObjectItem(jdata,"appid")) {
      app_id = cJSON_GetObjectItemCaseSensitive(jdata,"appid")->valuestring;
    } else {
      DEBUG_LOG_E("Cannot find port in JSON->data");
      result = -1;
    }   

  } else {
    DEBUG_LOG_E("Cannot find data in JSON");
    return -1;
  }


    
  if (result!=-1) {
    DEBUG_LOG_I("Session ID:%s,ACC IP:%s,PORT:%s,STA IP:%s,APP_ID:%s\n",session_id,acc_ip,port,sockets[index].clientIp,app_id);
    result = mp_start_session(session_id,sockets[index].clientIp,acc_ip,atoi(port),report_ip,atoi(report_port),app_id,timer_ms ,mp_version_num);

    if(cJSON_HasObjectItem(jobjReceived,"config")) {
      jconfig = cJSON_GetObjectItemCaseSensitive(jobjReceived,"config");
      int i,j;
      char *BQW_enabled_string = NULL;
      char *probability_string = NULL;
      struct apconfig config;

      int probability = 0;
      srand((unsigned)(time(NULL)));
      int rand_num = rand() % 100;      
      
      //processing config array
      //TODO: fix segmentation fault when get error config
      for (i = 0 ; i < cJSON_GetArraySize(jconfig) ; i++) {
        cJSON * subitem = cJSON_GetArrayItem(jconfig, i);
        if (subitem!=NULL) {
          BQW_enabled_string = cJSON_GetObjectItemCaseSensitive(subitem, "BQW_enabled")->valuestring;
          probability_string = cJSON_GetObjectItemCaseSensitive(subitem, "probability")->valuestring;
          if (BQW_enabled_string == NULL || probability_string == NULL ) {
            DEBUG_LOG_E("Cannot find BQW_enabled or probability in config item");
            continue;
          }
          probability = atoi(probability_string);
          //check if the random hit
          if (rand_num<=probability) {
            config.BQW_enabled = atoi(BQW_enabled_string);
		        DEBUG_LOG_I("probability hit, BQW_Enabled:%d",config.BQW_enabled);
			      hit_flag = 1;
            //check if config apply success, if failed , use BQW_enabled:0
            if (mp_apply_config(session_id,config,report)!=0) {
                DEBUG_LOG_E("mp_apply_config error");
            }

            break;
          } 
          rand_num = rand_num - probability;          
        }
      }

      //not hit, use default config
      if (hit_flag == 0) {
        DEBUG_LOG_E("probability error, use default config");
        config.BQW_enabled = 1;
        if (mp_apply_config(session_id,config,report)!=0) {
          DEBUG_LOG_E("mp_apply_config error");
        }
      }

    } else {
      DEBUG_LOG_E("Cannot find config in JSON");
    }    
    
  } 
    
  if(result==0) {
    DEBUG_LOG_I("Session ID:%s Start Success,report:%s\n",session_id,report);
  } else {
    DEBUG_LOG_E("Session ID:%s Start Failed\n",session_id);
  }
  send_handshake_response(index,result,mp_version_num,report);

}

void send_handshake_response(int index,int result,int mp_version_num,char* report) 
{
    cJSON *jobjToSend = cJSON_CreateObject();
    char result_str[32];
    sprintf(result_str, "%d", result);
    char ap_version_str[32];
    char *request;
    
    sprintf(ap_version_str, "%d", mp_version_num); 

  cJSON_AddItemToObject(jobjToSend, "cmd", cJSON_CreateString("start.handshake.rsp"));
  cJSON_AddItemToObject(jobjToSend, "result", cJSON_CreateString(result_str));
  if (report!=NULL) {
    cJSON_AddItemToObject(jobjToSend, "report", cJSON_CreateString(report));
  } else {
    cJSON_AddItemToObject(jobjToSend, "report", cJSON_CreateString("empty_report"));
  }
  
  cJSON_AddItemToObject(jobjToSend, "apversion", cJSON_CreateString(ap_version_str));

    request = cJSON_PrintUnformatted(jobjToSend);
    handleSendData(index, request, strlen(request)+1);

  free(request);

  cJSON_Delete(jobjToSend);

}

int handle_quit_cmd(cJSON *jobjReceived)
{
  return 0;
}

int handle_set_WMM_traffic(cJSON *jobjReceived)
{
  int wlan_interface = cJSON_GetObjectItemCaseSensitive(jobjReceived, "WLAN_Interface")->valueint;
  char *server_ip_address = cJSON_GetObjectItemCaseSensitive(jobjReceived, "Server_IP")->valuestring;
  int net_mask_length = cJSON_GetObjectItemCaseSensitive(jobjReceived, "Net_Mask_Length")->valueint;
  int server_port = cJSON_GetObjectItemCaseSensitive(jobjReceived, "Server_Port")->valueint;
  int ac_queue_tos = cJSON_GetObjectItemCaseSensitive(jobjReceived, "AC_Queue_TOS")->valueint;

  set_wmm_traffic(wlan_interface,server_ip_address,net_mask_length,server_port,ac_queue_tos );
  return 1; //TODO: use result code instead of 1
}

int handle_clear_WMM_traffic(cJSON *jobjReceived)
{
  clear_wmm_traffic(); 
  return 1; //TODO: use result code instead of 1
}

int handle_set_WMM_parameter(cJSON *jobjReceived)
{

  char *ac_queue_name = cJSON_GetObjectItemCaseSensitive(jobjReceived, "AC_QUEUE_NAME")->valuestring;
  char *parameter_name = cJSON_GetObjectItemCaseSensitive(jobjReceived, "AC_QUEUE_PARAMETER")->valuestring;
  char *parameter_number = cJSON_GetObjectItemCaseSensitive(jobjReceived, "AC_QUEUE_PARAMETER_VALUE")->valuestring;

  set_wmm_parameter(ac_queue_name,parameter_name,parameter_number);
  return 1; //TODO: use result code instead of 1
}
