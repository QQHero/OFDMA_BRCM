/* @author: Tencent slimehsiao */

#include "mp_server.h"
#include "mp_core.h"
#include "mp_udpclient.h"
#include "mp_util.h"
#include <stdio.h>
#include <time.h>
#include <signal.h>
#include "TencentWiFi.h"
#include <kwb_ioctl.h>
#include <iof_lib_drv.h>
#include <pthread.h>
#include <errno.h>


#define UDP_BUFSIZE 256
#define STARTGAME_MAX_BQW_ENABLED_STREAM_COUNT 1
#define COMMON_MAX_BQW_ENABLED_STREAM_COUNT 3
#define PROXY_LIST_SIZE 10
uint32_t magic_num = 2881128040; 
int BQW_enabled_stream_count = 0;
char BQW_enabled_string[32] = "BQW_enabled:1";
char BQW_disabled_string[32] = "BQW_enabled:0";
int priority_used_5G[4] = {0};
int queue_priority_5G[4] = {6,7,4,5};  //6,7 for VO.  4,5 for VI
int priority_used_2G[4] = {0};
int queue_priority_2G[4] = {6,7,4,5};  //6,7 for VO.  4,5 for VI

struct proxy_ip_node
{
	char ip_addr[32];
	int  ref_count;
	int  stream_id;
	int  stream_priority;
	int  BQW_enabled;
};
struct proxy_ip_node proxy_list[PROXY_LIST_SIZE];


void send_session_info(session_node* cb_node);


void init_proxy_list()
{
	for(int i = 0; i < PROXY_LIST_SIZE ; i++){
		strcpy(proxy_list[i].ip_addr, "");
		proxy_list[i].ref_count = -1;
		proxy_list[i].stream_id = -1;
		proxy_list[i].stream_priority = -1;
		proxy_list[i].BQW_enabled = -1;

	}

}

int get_proxy_ip_index(char* ip_addr)
{
	int i = 0;
	while (i < PROXY_LIST_SIZE){
		if(strcmp(proxy_list[i].ip_addr, ip_addr) == 0){
			return i;
		}
		i++;
	}
	debug_print("This proxy ip is not existed!\n");
	return -1;	
}

int add_proxy_ip_node(char* ip_addr, int ref_count, int stream_id, int stream_priority, int BQW_enabled)
{	
	int i = 0;
	while (i < PROXY_LIST_SIZE){
		if(strcmp(proxy_list[i].ip_addr, "") == 0){
			strcpy(proxy_list[i].ip_addr, ip_addr);
			proxy_list[i].ref_count = ref_count;
			proxy_list[i].stream_id = stream_id;
			proxy_list[i].stream_priority = stream_priority;
			proxy_list[i].BQW_enabled = BQW_enabled;
			return i;
		}
		i++;
	}
	debug_print("proxy ip list is full!\n");
	return -1;	

}

void delete_proxy_ip_node(int index)
{
	strcpy(proxy_list[index].ip_addr, "");
	proxy_list[index].ref_count = -1;
	proxy_list[index].stream_id = -1;
	proxy_list[index].stream_priority = -1;
	proxy_list[index].BQW_enabled = -1;
}

int assign_stream_priority(int freq_band)
{	

	int i = 0;
	while (i < 4){
		if(freq_band == FREQUENCY_BAND_5GHZ){
			if(priority_used_5G[i] == 0){
			priority_used_5G[i] = 1;
			return queue_priority_5G[i];
			}
		}
		if(freq_band == FREQUENCY_BAND_2GHZ){
			if(priority_used_2G[i] == 0){
			priority_used_2G[i] = 1;
			return queue_priority_2G[i];
			}
		}
		i++;
	}
	debug_print("stream priority assignment is full!\n");
	return -1;	
}

int release_stream_priority(int priority, int freq_band)
{	 
	int i = 0;
	while (i < 4){
		if(freq_band == FREQUENCY_BAND_5GHZ){
			if(queue_priority_5G[i] == priority){
				priority_used_5G[i] = 0;
				debug_print("release 5G stream priority:%d\n", priority);
				return 0;
			}
		}
		if(freq_band == FREQUENCY_BAND_2GHZ){
			if(queue_priority_2G[i] == priority){
				priority_used_2G[i] = 0;
				debug_print("release 2G stream priority:%d\n", priority);
				return 0;
			}
		}
		i++;
	}

	debug_print("release unassigned stream prority:%d in freg_band:%d!\n",priority, freq_band);
	return -1;
}

int check_app_stream_limit(char* app_id)
{
	if(strcmp(app_id, "startgame") == 0){
		return STARTGAME_MAX_BQW_ENABLED_STREAM_COUNT;
	}
	else
		return COMMON_MAX_BQW_ENABLED_STREAM_COUNT;
}



int mp_start_session(char* session_id, char* sta_ip_addr, char* proxy_ip_addr, int proxy_port, char* report_ip_addr, int report_port, char* app_id, int timer_ms, uint32_t version_num)
{
	char message[UDP_BUFSIZE];
	int mem_index;
	memset(message, 0, UDP_BUFSIZE);
	session_node* new_node = create_session_node(session_id, sta_ip_addr, proxy_ip_addr, proxy_port, report_ip_addr, report_port, app_id,timer_ms, version_num);
	if(new_node == NULL){
		debug_print("cannot create new session\n");
		return -1;
	}
	   
    /* session node already existed*/
	if(get_session_node(new_node) != NULL)
	{
		debug_print("session already existed\n");
		free(new_node);
		return 1;
	}
	debug_print("report ip addr:%s\n", new_node->report_ip_addr);
	debug_print("report port:%d\n", new_node->report_port);
	int fd = udp_sock_create(new_node->report_ip_addr, new_node->report_port, &new_node->addr);
	if(fd == -1){
		debug_print("udp_sock_create failed\n");
		free(new_node);
		return -1;
	}
	else{
		new_node->sock_udp_fd = fd; 
		debug_print("udp socket created: proxy ip-%s, port-%d",new_node->proxy_ip_addr, new_node->report_port);
	}
	
	if(ip_to_mac_address(new_node->sta_ip_addr, new_node->sta_mac_addr) == -1){
		debug_print("ip to mac address error\n");
		memset(message, 0, UDP_BUFSIZE);
		mem_index = compose_session_error_report(message, new_node->session_id, SESSION_ERROR_IPTOMACADDR_FAILED);	
		if(udp_send(new_node->sock_udp_fd,&new_node->addr, message, mem_index) == -1){
			debug_print("session id:%s udp send error\n",new_node->session_id);
		}	
		close(new_node->sock_udp_fd);
		free(new_node);
		return -1;
	}
	else
		debug_print("mac addr:%s\n",new_node->sta_mac_addr);

/*
	if(start_timer(new_node->session_id, &new_node->timer_id, new_node->timer_ms, timer_callback) == -1){
		debug_print("start_timer failed\n");
		memset(message, 0, UDP_BUFSIZE);
		mem_index = compose_error_report(message, new_node->session_id, SESSION_ERROR_TIMER_START_FAILED);	
		if(udp_send(new_node->sock_udp_fd,&new_node->addr, message, mem_index) == -1){
			debug_print("session id:%s udp send error\n",new_node->session_id);
		}	
		close(new_node->sock_udp_fd);
		free(new_node);
		return -1;
	}
*/
	if(insert_session_node(new_node) == -1)
	{
		debug_print("insert session node failed\n");
		free(new_node);
		return 1;
	}

	new_node->session_status = SESSION_STATUS_START;
	memset(message, 0, UDP_BUFSIZE);
	mem_index = compose_session_start_report(message, new_node->session_id);	
	if(udp_send(new_node->sock_udp_fd,&new_node->addr, message, mem_index) == -1){
			debug_print("session id:%s udp send error\n",new_node->session_id);
	}

	print_all_sessions();

    #if 0
	int stream_id = assign_stream_id();
	if(stream_id == -1){
		debug_print("stream_id assign failed\n");
		free(new_node);
		return -1;
	}
	else{
		new_node->stream_id = stream_id;
		debug_print("created stream_id: %d\n", new_node->stream_id);
	}
    #endif

	if(get_sta_freq_band(new_node) == -1){
		debug_print("get sta freg_band failed\n");
		free(new_node);
		return -1;
	}
	else
		debug_print("sta freg_band: %d", new_node->freg_band);

	return 0;
}

int mp_stop_session(char* session_id, int stop_reason)
{
	
	session_node* stop_node = get_session_node(session_id);
	char message[UDP_BUFSIZE];
	int mem_index;
	int result = 0;

	if(stop_node!= NULL){
	

        /*
		if(stop_timer(stop_node->timer_id) == -1){
			debug_print("stop_timer failed\n");
			memset(message, 0, UDP_BUFSIZE);
			mem_index = compose_error_report(message, stop_node->session_id, SESSION_ERROR_TIMER_STOP_FAILED);	
			if(udp_send(stop_node->sock_udp_fd,&stop_node->addr, message, mem_index) == -1){
				debug_print("session id:%s udp send error\n",stop_node->session_id);
			}	
			result = -1;
		}
		*/
	
		/* report session stop info to proxy*/
		stop_node->session_status = SESSION_STATUS_STOP;
		memset(message, 0, UDP_BUFSIZE);
		unsigned char ifname_macaddr[6]   = {0};
    	char wanip[MAX_ADDR_SIZE];
		char wanmac[MAX_ADDR_SIZE];

		memset(wanip, 0, MAX_ADDR_SIZE);
		if (0 == ifaddrs_get_ifip(get_eth_name(WAN_1), wanip))
		{
			printf("WAN PORT IP:%s\n", wanip);


		}
		memset(wanmac, 0, MAX_ADDR_SIZE);
		if (0 == ifaddrs_get_if_netmac(get_eth_name(WAN_1), ifname_macaddr))
		{
			sprintf(wanmac, "%02x:%02x:%02x:%02x:%02x:%02x",
					ifname_macaddr[0], ifname_macaddr[1], ifname_macaddr[2],
					ifname_macaddr[3], ifname_macaddr[4], ifname_macaddr[5]);
			printf("WAN MAC:%s\n", wanmac);

		}

		int mem_index = compose_session_stop_report(message, stop_node->session_id, stop_reason, stop_node->session_config.BQW_enabled, stop_node->mp_version_num, stop_node->app_id, wanmac, wanip);
		if(udp_send(stop_node->sock_udp_fd,&stop_node->addr, message, mem_index) == -1){
			debug_print("session id:%s udp send error\n",stop_node->session_id);
		}

		if(mp_reset_config(session_id) == -1){
			debug_print("mp_reset_config failed\n");
			memset(message, 0, UDP_BUFSIZE);
			mem_index = compose_session_error_report(message, stop_node->session_id, SESSION_ERROR_RESET_AC_QUEUE_CONFIG_FAILED);	
			if(udp_send(stop_node->sock_udp_fd,&stop_node->addr, message, mem_index) == -1){
				debug_print("session id:%s udp send error\n",stop_node->session_id);
			}	
			result = -1;
		}
		debug_print("mp_reset_config succeeded!\n");
		/* already report all UDP data to proxy, can delete session node (including socket fd) now*/
		if(delete_session_node(session_id) == -1){
			debug_print("delete_session_node failed\n");
			result = -1;
		}
		
	}
	else{
		debug_print("mp_stop_session: session_node id: %s not found error\n", session_id);
		result = -1;
	}
	debug_print("mp_stop_session leave\n");
	return result;
}

int mp_set_wme_ac_ip(char *server_ip,int netlen,int srcport,int priority,int stream_id, int freq_band)
{
     kwb_wme_info_t msg;
     //unsigned char *ifname = "wlan1";
	 unsigned char *ifname = NULL;
     struct in_addr srcip;
     unsigned int netmask;
     int ret,i;

	 if(freq_band == FREQUENCY_BAND_5GHZ)
	 	ifname = "wlan1";
	 if(freq_band == FREQUENCY_BAND_2GHZ)
	 	ifname = "wlan0";

    inet_pton(AF_INET,server_ip,(void*)&srcip);
    
     //netmask
     if (netlen < 0 || netlen > 32) {
         printf("error: %s[%d]: netmask len rang 1~32 cur value %d!\n"
             , __func__, __LINE__
             , netlen);
         return WIFIBASE_OUTRANGE;
     }
     if (netlen > 0) {
         netmask = 0x80000000;
     } else {
         netmask = 0;
     }
     for (i = 0; i < netlen-1; i++) {
         netmask = netmask >>1;
         netmask |= 0x80000000;
     }
     //srcport
     if (srcport < 0 || srcport > 0xffff) {
         printf("ERROR: %s[%d]: srcport rang 0~65535 cur value %d!\n"
             , __func__, __LINE__
             , srcport);
         return WIFIBASE_OUTRANGE;
     }
     //priority
     if (priority < 0 || priority > 7) {
         printf("ERROR: %s[%d]: priority rang 0~7cur value %d!\n"
             , __func__, __LINE__
             , priority);
         return WIFIBASE_OUTRANGE;
     }
     
     memset(&msg, 0, sizeof(kwb_wme_info_t));
     msg.srcip = ntohl(srcip.s_addr);
     msg.netmask = netmask;
     msg.srcport = srcport;
     msg.priority = priority;
     msg.itemid = stream_id;
    
     printf("%s[%d]: set ip 0x%08x:%u netmask 0x%08x pri %u [item:%u] [ifname:%s]\n"
         , __func__, __LINE__
         , msg.srcip
         , msg.srcport
         , msg.netmask
         , msg.priority
         , msg.itemid
		 , ifname
		 );
     ret = uwb_set_wme_ac_ip(ifname, &msg);
     if (ret) {
         printf("%s[%d] uwb_set_wme_ac_ip error. ret = %d\n", __func__, __LINE__, ret);
         perror("Error:");
     }
    
     return ret;
}

int add_BQW_disable_proxy_node(char* proxy_ip_addr, char* result)
{
	int proxy_index;
	proxy_index = add_proxy_ip_node(proxy_ip_addr, 1, -1, -1, 0);
	if(proxy_index < 0){
		debug_print("add_proxy_ip_node failed\n");
		return -1;
	}
	else{
		strcpy(result, BQW_disabled_string);
		return proxy_index;
	}

}

int add_BQW_enable_proxy_node(char* proxy_ip_addr, int stream_id, int stream_prority, char* result)
{
    int proxy_index;
	proxy_index = add_proxy_ip_node(proxy_ip_addr, 1, stream_id, stream_prority, 1);
	if(proxy_index < 0){
		debug_print("add_proxy_ip_node failed\n");
		return -1;
	}
	else{
		strcpy(result, BQW_enabled_string);
		return proxy_index;
	}

}


int mp_apply_config(char* session_id, struct apconfig config, char* result)
{	
    if(result == NULL){
		debug_print("mp_apply_config result pointer not allocated!\n");
		return -1;
	}
	else{

		session_node* cf_node = get_session_node(session_id);

		if (cf_node != NULL) {
				
			int stream_priority;
			int stream_id;
			int proxy_ip_index;

			proxy_ip_index = get_proxy_ip_index(cf_node->proxy_ip_addr);
			debug_print("mp_apply_config: proxy_ip_index: %d\n",proxy_ip_index);

			// proxy ip exists in the array, just return the config string
			if(proxy_ip_index >= 0){
				proxy_list[proxy_ip_index].ref_count += 1;
				if(proxy_list[proxy_ip_index].BQW_enabled == 1){
					strcpy(result, BQW_enabled_string);
					cf_node->session_config.BQW_enabled = 1;
					cf_node->proxy_ip_index = proxy_ip_index;
					cf_node->stream_id = proxy_list[proxy_ip_index].stream_id;
					cf_node->stream_priority = proxy_list[proxy_ip_index].stream_priority;
					strcpy(result, BQW_enabled_string);
					debug_print("mp_apply_config point 1\n");
				}
				if(proxy_list[proxy_ip_index].BQW_enabled == 0){
					strcpy(result, BQW_disabled_string);
					cf_node->session_config.BQW_enabled = 0;
					cf_node->proxy_ip_index = proxy_ip_index;
					strcpy(result, BQW_disabled_string);
					debug_print("mp_apply_config point 2\n");
				}

				return 0;
			}
			//proxy ip not exists
			else{
				if(config.BQW_enabled == 1){
		
					debug_print("app_stream_BQW_enabled_limit:%d\n", check_app_stream_limit(cf_node->app_id));
					if(BQW_enabled_stream_count < check_app_stream_limit(cf_node->app_id)){

						stream_id = assign_stream_id();

						if(stream_id == -1){
							debug_print("stream_id assign failed\n");
							send_session_error_report(cf_node, SESSION_ERROR_STREAM_ID_ASSIGN_FAILED);
							
							cf_node->session_config.BQW_enabled = 0;
						
							int index = add_BQW_disable_proxy_node(cf_node->proxy_ip_addr,result);
							if(index == -1){
								debug_print("add_proxy_ip_node failed\n");
								return -1;
							}
							else{
								cf_node->proxy_ip_index = index;
								debug_print("mp_apply_config point 3\n");
								return 0;
							}

						}
						else{
							cf_node->stream_id = stream_id;
						}

						stream_priority = assign_stream_priority(cf_node->freg_band);

						if(stream_priority == -1){
							debug_print("assign stream priority failed for session_id:%s\n",cf_node->session_id);
							//release stream id
							release_stream_id(cf_node->stream_id);

							send_session_error_report(cf_node, SESSION_ERROR_STREAM_PRIORITY_ASSIGN_FAILED);

							cf_node->session_config.BQW_enabled = 0;

							int index = add_BQW_disable_proxy_node(cf_node->proxy_ip_addr,result);
							if(index == -1){
								debug_print("add_proxy_ip_node failed\n");
								return -1;
							}
							else{
								cf_node->proxy_ip_index = index;
								debug_print("mp_apply_config point 4\n");
								return 0;
							}			
						}
						else{
							cf_node->stream_priority = stream_priority;
						}
							
						debug_print("mp_apply_config BQW enabled, ip_addr:%s, port:%d, stream id:%d, stream priority:%d\n",cf_node->proxy_ip_addr,cf_node->proxy_port,cf_node->stream_id, stream_priority);
						int ac_result = mp_set_wme_ac_ip(cf_node->proxy_ip_addr, 24,  cf_node->proxy_port, cf_node->stream_priority, cf_node->stream_id, cf_node->freg_band);
						usleep(200000); //200ms
			
						if(ac_result != 0){

							debug_print("mp_apply_config: set_wme_ac_ip failed\n");

							//release stream id
							release_stream_id(cf_node->stream_id);
							//release stream priority
							release_stream_priority(cf_node->stream_priority, cf_node->freg_band);

							send_session_error_report(cf_node, SESSION_ERROR_APPLY_AC_QUEUE_CONFIG_FAILED);

							cf_node->session_config.BQW_enabled = 0;

							int index = add_BQW_disable_proxy_node(cf_node->proxy_ip_addr,result);
							if(index == -1){
								debug_print("add_proxy_ip_node failed\n");
								return -1;
							}
							else{
								cf_node->proxy_ip_index = index;
								debug_print("mp_apply_config point 5\n");
								return 0;	
							}

						}
						//after all, BQW enabled succesfully
						debug_print("BQW enable config apply succesfully\n");

						cf_node->session_config.BQW_enabled = 1;
						BQW_enabled_stream_count += 1;
						debug_print("BQW enabled stream count:%d\n", BQW_enabled_stream_count);

			
						int index = add_BQW_enable_proxy_node(cf_node->proxy_ip_addr,cf_node->stream_id, cf_node->stream_priority, result);
						if(index < 0){
							debug_print("add_proxy_ip_node failed\n");
							return -1;
						}
						else{
							cf_node->proxy_ip_index = index;
							debug_print("mp_apply_config point 6\n");
							return 0;
						}
					}
					else{
						debug_print("BQW_enabled_stream count exceeds maximum value, BQW disable\n");

						send_session_error_report(cf_node,SESSION_ERROR_BQW_ENABLE_STREAM_EXCEED_MAX);

						cf_node->session_config.BQW_enabled = 0;

						int index = add_BQW_disable_proxy_node(cf_node->proxy_ip_addr,result);
						if(index == -1){
							debug_print("add_proxy_ip_node failed\n");
							return -1;
						}
						else{
							cf_node->proxy_ip_index = index;
							debug_print("mp_apply_config point 7\n");
							return 0;
						}
					}
				}
				else if(config.BQW_enabled == 0){
					
					cf_node->session_config.BQW_enabled = 0;

					int index = add_BQW_disable_proxy_node(cf_node->proxy_ip_addr,result);
					if(index == -1){
						debug_print("add_proxy_ip_node failed\n");
						return -1;
					}
					else{
						cf_node->proxy_ip_index = index;
						debug_print("mp_apply_config point 8\n");
						return 0;
					}
				}

			}
		}

		else{
			debug_print("mp_apply_config: session_node id: %s not found error\n", session_id);
			return -1;
		}	
	}
}

int mp_reset_config(char* session_id)
{
	session_node* rs_node = get_session_node(session_id);
	if (rs_node != NULL) {
		debug_print("mp_reset_config, proxy ip index:%d, BQW enabled:%d\n", rs_node->proxy_ip_index, rs_node->session_config.BQW_enabled);
		// only handle the case with proxy ip already added to the list, other case is fatal error (not handling)
		if(rs_node->proxy_ip_index >= 0){

			//int end_result = 0;
		
			proxy_list[rs_node->proxy_ip_index].ref_count -= 1;

			//remove element from the list and set wifibase api if BQW enabled
			if(proxy_list[rs_node->proxy_ip_index].ref_count == 0){

				if(proxy_list[rs_node->proxy_ip_index].BQW_enabled == 1){

					int ac_result;

					debug_print("mp_reset_config ref_count=0, stream id:%d, stream priority:%d\n",rs_node->stream_id,rs_node->stream_priority);
					ac_result = mp_set_wme_ac_ip("0.0.0.0", 0,  0, rs_node->stream_priority, rs_node->stream_id, rs_node->freg_band);

					usleep(200000); //200ms
					if(ac_result == 0){
						release_stream_priority(rs_node->stream_priority,rs_node->freg_band);
						release_stream_id(rs_node->stream_id);
						BQW_enabled_stream_count -= 1;
						debug_print("BQW enabled stream count:%d\n", BQW_enabled_stream_count);
					}
					else{
						debug_print("mp_reset_config: set_wme_ac_ip failed\n");
						send_session_error_report(rs_node, SESSION_ERROR_RESET_AC_QUEUE_CONFIG_FAILED);
					}

				}

				//set this proxy list element to initial value
				delete_proxy_ip_node(rs_node->proxy_ip_index);

			}
			return 0;
		}
		else{
			debug_print("mp_reset_config: proxy_ip_index is illegal\n");
			return -1;
		}
	}
	else {
		debug_print("mp_reset_config: session_node id: %s not found error\n", session_id);
		return -1;
	}		
}

int mp_report_heartbeat(char* session_id)
{
    session_node* hb_node = get_session_node(session_id);
	if(hb_node!= NULL){
		hb_node->life_time = MAX_SESSION_LIFE_TIME;
		return 0;
	}
	else{
		debug_print("mp_report_heartbeat: session_node id: %s not found error\n", session_id);
		return -1;
	}	
}

void mp_session_unit_test(void)
{



}

void gather_ap_info() 
{
	//get each session node in list and send the info to server
	session_node* node;
	node = get_first_session_node();
	while(node!=NULL) {
		send_session_info(node);
		node = node->next;
	}		
}

void send_session_info(session_node* cb_node) 
{
    
	char message[UDP_BUFSIZE];
	int mem_index;

	if(cb_node!= NULL){

		int remain_time = cb_node->life_time - cb_node->timer_ms;
		if(remain_time < 0){
			debug_print("session id:%s life time expired\n",cb_node->session_id);
			mp_stop_session(cb_node->session_id, SESSION_STOPREASON_TIMER_EXPIRED);
			return;
		}
		cb_node->life_time = remain_time;
		
	
		ch_info* new_chinfo = get_channel_info(cb_node);
		if(new_chinfo == NULL){
			debug_print("get channel info failed\n");
			memset(message, 0, UDP_BUFSIZE);
			mem_index = compose_session_error_report(message,cb_node->session_id, SESSION_ERROR_ABNORMAL_CHANNEL_DATA);
			if(udp_send(cb_node->sock_udp_fd,&cb_node->addr, message, mem_index) == -1){
				debug_print("session id:%s udp send error\n",cb_node->session_id);
			}
			return;
		}	
		else{
			
			debug_print("session id:%s, idle rate:%d\n",cb_node->session_id, new_chinfo->idle_rate);
			debug_print("broken count:%d\n",new_chinfo->brokensignal_count);
			debug_print("noise level:%d\n",new_chinfo->noise_level);
			
		}

	
		ap_info* new_apinfo = get_bssap_info(cb_node);
		if(new_apinfo == NULL){
			debug_print("get bssap info failed\n");
			memset(message, 0, UDP_BUFSIZE);
			mem_index = compose_session_error_report(message,cb_node->session_id, SESSION_ERROR_ABNORMAL_BSS_DATA);
			if(udp_send(cb_node->sock_udp_fd,&cb_node->addr, message, mem_index) == -1){
				debug_print("session id:%s udp send error\n",cb_node->session_id);
			}
			free(new_chinfo);
			return;
		}
		else{
			debug_print("sta count:%d\n",new_apinfo->sta_count);
		}

		sta_info* new_stainfo = get_station_info(cb_node);
		if(new_stainfo == NULL){
			debug_print("get station info failed\n");
			memset(message, 0, UDP_BUFSIZE);
			mem_index = compose_session_error_report(message,cb_node->session_id, SESSION_ERROR_ABNORMAL_STA_DATA);
			if(udp_send(cb_node->sock_udp_fd,&cb_node->addr, message, mem_index) == -1){
				debug_print("session id:%s udp send error\n",cb_node->session_id);
			}
			free(new_chinfo);
			free(new_apinfo);
			return;
		}
		else{
				

				
					/* mark status to ongoing only after first sample is got*/
				if(cb_node->sample_number > 1){
					if(cb_node->sample_number == 2){
						cb_node->session_status = SESSION_STATUS_ONGOING;	
						debug_print("change to session status ongoing\n");
					}
					debug_print("phy rate:%d\n", new_stainfo->phy_rate);
					debug_print("phy rate fb:%d\n", new_stainfo->fb_phy_rate);
					debug_print("antenna count:%d\n", new_stainfo->antenna_count);
					debug_print("rssi:%d\n", new_stainfo->rssi);
					debug_print("rx fail count:%d\n", new_stainfo->rx_decrypt_failure_count);
					debug_print("session id:%s, tx data rate:%f\n", cb_node->session_id, new_stainfo->tx_data_rate);
					debug_print("tx fail count:%d\n", new_stainfo->tx_failure_count);
					debug_print("tx attemp aveage count:%f\n", new_stainfo->tx_attempt_count);
					debug_print("channel num:%d\n", new_stainfo->channel_num);
					debug_print("channel bw:%d\n", new_stainfo->channel_bw);
					debug_print("frequency band:%d\n", new_stainfo->frequency_band);
			
				}
			
	
			
		}

#if 0
		//check ac queue flow data rate 
		if(cb_node->session_config.BQW_enabled == 1){
			int ac_queue_data_rate =  get_pktq_stats(AC_QUEUE_ID);
			int min_rate_range = (int)(new_stainfo->tx_data_rate * 0.5);
			int max_rate_range = (int)(new_stainfo->tx_data_rate * 2);
			debug_print("min rate:%d, max rate:%d\n",min_rate_range,max_rate_range);
			debug_print("ac queue data rate:%d\n",ac_queue_data_rate);
			if(ac_queue_data_rate < min_rate_range || ac_queue_data_rate > max_rate_range){
				debug_print("ac queue flow error\n");
				char message[UDP_BUFSIZE];
				memset(message, 0, UDP_BUFSIZE);
				mem_index = compose_error_report(message, cb_node->session_id, SESSION_ERROR_AC_QUEUE_FLOW_ABNORMAL);	
				if(udp_send(cb_node->sock_udp_fd,&cb_node->addr, message, mem_index) == -1){
					debug_print("session id:%s udp send error\n",cb_node->session_id);
				}	
				
			}
		}
#endif
		if(cb_node->session_status == SESSION_STATUS_ONGOING){
	
			memset(message, 0, UDP_BUFSIZE);
			//add magic number integer in the head
			int magic_num_net = htonl(magic_num);
			memcpy(message, &magic_num_net, 4);
			mem_index += 4;
			mem_index = compose_tlv_string(REPORT_TAG_SESSION_ID,MAX_SESSION_ID_LENGTH,cb_node->session_id,message,mem_index);
			//mem_index = compose_tlv_byte(REPORT_TAG_SESSION_CONFIG,cb_node->session_config.BQW_enabled,message, mem_index);
			mem_index = compose_tlv_byte(REPORT_TAG_SESSION_RSSI,new_stainfo->rssi,message,mem_index);
			mem_index = compose_tlv_lint(REPORT_TAG_SESSION_PHY_RATE,new_stainfo->phy_rate,message, mem_index);
			mem_index = compose_tlv_lint(REPORT_TAG_SESSION_FB_PHY_RATE,new_stainfo->fb_phy_rate,message, mem_index);
			mem_index = compose_tlv_byte(REPORT_TAG_SESSION_ANTENNA_COUNT,new_stainfo->antenna_count,message, mem_index);
			mem_index = compose_tlv_byte(REPORT_TAG_SESSION_STA_COUNT,new_apinfo->sta_count,message, mem_index);
			mem_index = compose_tlv_byte(REPORT_TAG_SESSION_IDLE_RATE,new_chinfo->idle_rate,message, mem_index);
			mem_index = compose_tlv_float(REPORT_TAG_SESSION_TX_ATTEMPT_AVERAGE,new_stainfo->tx_attempt_count,message, mem_index);
			mem_index = compose_tlv_lint(REPORT_TAG_SESSION_TX_FAIL_COUNT,new_stainfo->tx_failure_count,message, mem_index);
			mem_index = compose_tlv_lint(REPORT_TAG_SESSION_RX_DECRYPT_FAIL_COUNT,new_stainfo->rx_decrypt_failure_count,message, mem_index);
			mem_index = compose_tlv_float(REPORT_TAG_SESSION_TX_DATA_RATE,new_stainfo->tx_data_rate,message, mem_index);
			mem_index = compose_tlv_lint(REPORT_TAG_SESSION_BROKENSIGNAL_COUNT,new_chinfo->brokensignal_count,message, mem_index);
			mem_index = compose_tlv_byte(REPORT_TAG_SESSION_NOISE_LEVEL,new_chinfo->noise_level,message, mem_index);
			mem_index = compose_tlv_byte(REPORT_TAG_SESSION_SESSION_STATUS,cb_node->session_status,message, mem_index);
			mem_index = compose_tlv_byte(REPORT_TAG_SESSION_CHANNEL_NUM, new_stainfo->channel_num, message, mem_index);
			mem_index = compose_tlv_byte(REPORT_TAG_SESSION_CHANNEL_BW, new_stainfo->channel_bw, message, mem_index);
			mem_index = compose_tlv_byte(REPORT_TAG_SESSION_FREQUENCY_BAND, new_stainfo->frequency_band, message, mem_index);
		
	


			if(udp_send(cb_node->sock_udp_fd,&cb_node->addr, message, mem_index) == -1){
				debug_print("session id:%s udp send error\n",cb_node->session_id);
			}	

		}
				

		free(new_chinfo);
		free(new_apinfo);
		free(new_stainfo);
	
	}
	else{
		debug_print("timer_callback: session_node not found error\n");
	}

}



int compose_session_start_report(char* message, char* session_id){

	int mem_index = 0;
	//add magic number integer in the head
   	uint32_t magic_num_net = htonl(magic_num);
    memcpy(message, &magic_num_net, 4);
	mem_index += 4;
	mem_index = compose_tlv_string(REPORT_TAG_SESSION_ID,MAX_CHAR_SIZE,session_id,message,mem_index);
	mem_index = compose_tlv_byte(REPORT_TAG_SESSION_SESSION_STATUS,SESSION_STATUS_START,message, mem_index);
	return mem_index;
	
}

int compose_session_stop_report(char* message, char* session_id, int stop_reason, int bqw_config, uint32_t mp_version_num, char* app_id, char* ap_mac_addr, char* ap_ip_addr){

	int mem_index = 0;
	//add magic number integer in the head
   	uint32_t magic_num_net = htonl(magic_num);
    memcpy(message, &magic_num_net, 4);
	mem_index += 4;
	mem_index = compose_tlv_string(REPORT_TAG_SESSION_ID, MAX_CHAR_SIZE, session_id, message, mem_index);
	mem_index = compose_tlv_byte(REPORT_TAG_SESSION_CONFIG, bqw_config, message, mem_index);
	mem_index = compose_tlv_byte(REPORT_TAG_SESSION_SESSION_STATUS,SESSION_STATUS_STOP,message, mem_index);
	mem_index = compose_tlv_lint(REPORT_TAG_SESSION_VERSION_NUM,mp_version_num,message, mem_index);
	mem_index =	compose_tlv_string(REPORT_TAG_SESSION_APP_ID,MAX_APP_ID_LENGTH,app_id,message,mem_index);
	mem_index = compose_tlv_byte(REPORT_TAG_SESSION_STOP_REASON,stop_reason,message, mem_index);
	
	if(ap_mac_addr != NULL){
		mem_index = compose_tlv_string(REPORT_TAG_SESSION_AP_MAC_ADDR, MAX_ADDR_SIZE, ap_mac_addr, message, mem_index);
	}
	if(ap_ip_addr != NULL){
		mem_index = compose_tlv_string(REPORT_TAG_SESSION_AP_IP_ADDR, MAX_ADDR_SIZE, ap_ip_addr, message, mem_index);
	}
	return mem_index;
	
}

int compose_session_error_report(char* message, char* session_id, uint8_t error_code){

	int mem_index = 0;
	//add magic number integer in the head
   	uint32_t magic_num_net = htonl(magic_num);
    memcpy(message, &magic_num_net, 4);
	mem_index += 4;
	mem_index = compose_tlv_string(REPORT_TAG_SESSION_ID,MAX_CHAR_SIZE,session_id,message,mem_index);
	mem_index = compose_tlv_byte(REPORT_TAG_SESSION_SESSION_STATUS,SESSION_STATUS_ERROR,message, mem_index);
	mem_index = compose_tlv_byte(REPORT_TAG_SESSION_ERROR_CODE,error_code,message, mem_index);
	return mem_index;
	
}

int compose_tlv_string(uint8_t tag, uint8_t length, char* value, char* message, int mem_index)
{

	memcpy(message + mem_index, &tag, 1);
	mem_index += 1;
	memcpy(message + mem_index, &length, 1);
	mem_index += 1;
	memcpy(message + mem_index, value, length);
	mem_index += length;

	return mem_index;
	
}

int compose_tlv_sint(uint8_t tag, int16_t value, char* message, int mem_index)
{

	memcpy(message + mem_index, &tag, 1);
	mem_index += 1;
	uint8_t length = 2;
	memcpy(message + mem_index, &length, 1);
	mem_index += 1;
	uint16_t value_ns = htons(value);
	memcpy(message + mem_index, &value_ns, length);
	mem_index += length;

	return mem_index;
}

int compose_tlv_lint(uint8_t tag, uint32_t value, char* message, int mem_index)
{
	memcpy(message + mem_index, &tag, 1);
	mem_index += 1;
	uint8_t length = 4;
	memcpy(message + mem_index, &length, 1);
	mem_index += 1;
	uint32_t value_ns = htonl(value);
	memcpy(message + mem_index, &value_ns, length);
	mem_index += length;

	return mem_index;
}


int compose_tlv_float(uint8_t tag, float value, char* message, int mem_index)
{
	memcpy(message + mem_index, &tag, 1);
	mem_index += 1;
	uint8_t length = 4;
	memcpy(message + mem_index, &length, 1);
	mem_index += 1;
	char *byte_ptr = &value;	
	char byte3 = (char)*byte_ptr;
	char byte2 = (char)*(byte_ptr+1);
	char byte1 = (char)*(byte_ptr+2);
	char byte0 = (char)*(byte_ptr+3);
	memcpy(message + mem_index, &byte0, 1);
	mem_index += 1;
	memcpy(message + mem_index, &byte1, 1);
	mem_index += 1;
	memcpy(message + mem_index, &byte2, 1);
	mem_index += 1;	
	memcpy(message + mem_index, &byte3, 1);
	mem_index += 1;

	return mem_index;
}

int compose_tlv_byte(uint8_t tag, uint8_t value, char* message, int mem_index)
{

	memcpy(message + mem_index, &tag, 1);
	mem_index += 1;
	uint8_t length = 1;
	memcpy(message + mem_index, &length, 1);
	mem_index += 1;
	memcpy(message + mem_index, &value, length);
	mem_index += length;

	return mem_index;
}

void send_session_error_report(session_node* err_node, uint8_t error_code)
{
	char message[UDP_BUFSIZE];
	int mem_index;
	memset(message, 0, UDP_BUFSIZE);
	mem_index = compose_session_error_report(message, err_node->session_id, error_code);	
	if(udp_send(err_node->sock_udp_fd,&err_node->addr, message, mem_index) == -1){
		debug_print("session id:%s udp send error\n",err_node->session_id);
	}	
}