#ifndef _TENCENTWIFI_H_
#define _TENCENTWIFI_H_
#include <stdint.h>
#include "cJSON.h"

struct ac_txq_params {
    //enum 80211_ac ac;
    int aifs;
    int cw_min;
    int cw_max;
    int txop;
};

struct channel_info {
	uint8_t idle_rate;
	int8_t noise_level;
	uint32_t brokensignal_count;
};
typedef struct channel_info ch_info;

struct bssap_info {
	uint8_t sta_count;
};
typedef struct bssap_info ap_info;

struct station_info {
	int8_t  rssi;
	uint32_t phy_rate;
	uint32_t fb_phy_rate;  //fallback phy rate
	uint8_t  antenna_count;
	float    tx_data_rate;
	float    tx_attempt_count;
	uint32_t    tx_failure_count;
	uint32_t    rx_decrypt_failure_count;
	//char     chanspec[10];
	uint8_t   channel_num;
	uint8_t   channel_bw;
	uint8_t   frequency_band;

};
typedef struct station_info sta_info;

struct session_linked_list;
typedef struct session_linked_list session_node;

#define MAX_STRING_LENGTH 256
#define MAX_WLAN_CMDS 3
#define MAX_SESSION_ID_LENGTH 64
#define MAX_APP_ID_LENGTH 16
#define MAX_CHANSPEC_LENGTH 10

#define MAX_SESSION_LIFE_TIME 30000   //30 seconds

#define MAX_CONFIGS 1


//session_status
#define SESSION_STATUS_START 1
#define SESSION_STATUS_ONGOING 2
#define SESSION_STATUS_STOP 3
#define SESSION_STATUS_ERROR 4

//session stop reason
#define SESSION_STOPREASON_NORMAL 1
#define SESSION_STOPREASON_TIMER_EXPIRED 2

//session error code
#define SESSION_NO_ERROR 0
#define SESSION_ERROR_ABNORMAL_CHANNEL_DATA 1
#define SESSION_ERROR_ABNORMAL_BSS_DATA 2
#define SESSION_ERROR_ABNORMAL_STA_DATA 3
#define SESSION_ERROR_APPLY_AC_QUEUE_CONFIG_FAILED 4
#define SESSION_ERROR_RESET_AC_QUEUE_CONFIG_FAILED 5
#define SESSION_ERROR_AC_QUEUE_FLOW_ABNORMAL 6
#define SESSION_ERROR_TIMER_START_FAILED 7
#define SESSION_ERROR_TIMER_STOP_FAILED 8
#define SESSION_ERROR_IPTOMACADDR_FAILED 9
#define SESSION_ERROR_STREAM_ID_ASSIGN_FAILED 10
#define SESSION_ERROR_STREAM_PRIORITY_ASSIGN_FAILED 11
#define SESSION_ERROR_BQW_ENABLE_STREAM_EXCEED_MAX 12

//proxy report TLV tag number
#define REPORT_TAG_SESSION_ID 1
#define REPORT_TAG_SESSION_CONFIG 2
#define REPORT_TAG_SESSION_RSSI 3
#define REPORT_TAG_SESSION_PHY_RATE 4
#define REPORT_TAG_SESSION_FB_PHY_RATE 5
#define REPORT_TAG_SESSION_ANTENNA_COUNT 6
#define REPORT_TAG_SESSION_STA_COUNT 7
#define REPORT_TAG_SESSION_IDLE_RATE 8
#define REPORT_TAG_SESSION_TX_ATTEMPT_AVERAGE 9
#define REPORT_TAG_SESSION_TX_FAIL_COUNT 10
#define REPORT_TAG_SESSION_RX_DECRYPT_FAIL_COUNT 11
#define REPORT_TAG_SESSION_TX_DATA_RATE 12
#define REPORT_TAG_SESSION_BROKENSIGNAL_COUNT 13
#define REPORT_TAG_SESSION_NOISE_LEVEL 14
#define REPORT_TAG_SESSION_SESSION_STATUS 15
#define REPORT_TAG_SESSION_VERSION_NUM 16
#define REPORT_TAG_SESSION_APP_ID 17
#define REPORT_TAG_SESSION_ERROR_CODE 18
#define REPORT_TAG_SESSION_STOP_REASON 19
#define REPORT_TAG_SESSION_CHANNEL_NUM 20
#define REPORT_TAG_SESSION_CHANNEL_BW 21
#define REPORT_TAG_SESSION_FREQUENCY_BAND 22
#define REPORT_TAG_SESSION_AP_MAC_ADDR 23
#define REPORT_TAG_SESSION_AP_IP_ADDR 24





#define FREQUENCY_BAND_2GHZ 0
#define FREQUENCY_BAND_5GHZ 1



#define CHANNEL_BW_20MHZ 0
#define CHANNEL_BW_40MHZ 1
#define CHANNEL_BW_80MHZ 2
#define CHANNEL_BW_160MHZ 3















struct JSON_CMD {
    char cmd_string[MAX_STRING_LENGTH];
    int (*handle_function)(int,cJSON *);
};

struct apconfig {
    int BQW_enabled;
};

struct session_linked_list;
typedef struct session_linked_list session_node;


int set_wmm_traffic(int wlan_interface,char *server_ip_address,int net_mask_length,int port,int ac_queue_tos );
int clear_wmm_traffic();
int set_ampdu_length(int length);
int set_wmm_parameter(char* ac_queue_name,char* parameter_name,char* parameter_number) ;
int ip_to_mac_address(char* ip_addr, char* mac_address) ;
ch_info* get_channel_info();
ap_info* get_bssap_info();
sta_info* get_station_info(session_node* );
int get_pktq_stats(int ac_queue_id);
int disable_wlan0();
int get_sta_freq_band(session_node* node);





#endif


