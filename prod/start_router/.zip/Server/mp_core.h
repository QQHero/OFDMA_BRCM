/* @author: Tencent slimehsiao */
#ifndef _MPCORE_H_
#define _MPCORE_H_

struct apconfig;
typedef struct session_linked_list session_node;


int mp_start_session(char* session_id, char* sta_ip_addr, char* proxy_ip_addr, int proxy_port, char* report_ip_addr, int report_port, char* app_id, int timer_ms, uint32_t version_num);
void mp_session_unit_test(void);
//int mp_apply_config(char* session_id, struct apconfig config);
int mp_apply_config(char* session_id, struct apconfig config, char* result);
int mp_stop_session(char* session_id, int reason);
int mp_report_heartbeat(char* session_id);
void timer_callback(int signo, siginfo_t *si, void *uc);
void gather_ap_info();
int assign_stream_priority(int freq_band);
int release_stream_priority(int priority, int freq_band);
void init_proxy_list();



int compose_tlv_string(uint8_t tag, uint8_t length, char* value, char* message, int mem_index);
int compose_tlv_sint(uint8_t tag, int16_t value, char* message, int mem_index);
int compose_tlv_lint(uint8_t tag, uint32_t value, char* message, int mem_index);
int compose_tlv_byte(uint8_t tag, uint8_t value, char* message, int mem_index);
int compose_tlv_float(uint8_t tag, float value, char* message, int mem_index);
int compose_session_stop_report(char* message, char* session_id, int stop_reason, int bqw_config, uint32_t mp_version_num, char* app_id, char* ap_mac_addr, char* ap_ip_addr);
int compose_session_error_report(char* message, char* session_id, uint8_t error_code);
int compose_session_start_report(char* message, char* session_id);
void send_session_error_report(session_node* err_node, uint8_t error_code);







#endif
